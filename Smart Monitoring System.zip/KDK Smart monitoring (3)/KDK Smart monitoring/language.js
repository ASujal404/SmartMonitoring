// ✅ Language Data for Translation
const translations = {
    en: {
        "page-title": "🌱 Smart Agriculture Monitoring",
        "login-heading": "🔐 Login",
        "email-placeholder": "Email",
        "password-placeholder": "Password",
        "login-btn": "Login",
        "signup-text": "Don't have an account? <a href='signup.html'>Signup</a>",
        "error-message": "❌ Invalid Candidate! Please check your credentials.",
        "navbar-home": "Home",
        "navbar-about": "About Us",
        "navbar-contact": "Contact",
        "navbar-language": "Language"
    },
    mr: {
        "page-title": "🌱 स्मार्ट शेती मॉनिटरिंग",
        "login-heading": "🔐 लॉगिन",
        "email-placeholder": "ईमेल",
        "password-placeholder": "पासवर्ड",
        "login-btn": "लॉगिन",
        "signup-text": "खाते नाही? <a href='signup.html'>नोंदणी करा</a>",
        "error-message": "❌ अमान्य उमेदवार! कृपया आपले प्रमाणपत्र तपासा.",
        "navbar-home": "मुख्यपृष्ठ",
        "navbar-about": "आमच्याबद्दल",
        "navbar-contact": "संपर्क करा",
        "navbar-language": "भाषा"
    }
};

// ✅ Function to Change Language
function changeLanguage(lang) {
    localStorage.setItem("selectedLanguage", lang); // Save selected language

    // Update all text based on the selected language
    document.querySelectorAll("[data-translate]").forEach(element => {
        let key = element.getAttribute("data-translate");
        if (translations[lang][key]) {
            element.innerHTML = translations[lang][key];
        }
    });

    // Update placeholders separately
    document.getElementById("email")?.setAttribute("placeholder", translations[lang]["email-placeholder"]);
    document.getElementById("password")?.setAttribute("placeholder", translations[lang]["password-placeholder"]);
}

// ✅ Function to Load Language on Page Load
function loadLanguage() {
    let savedLang = localStorage.getItem("selectedLanguage") || "en";
    document.getElementById("language-selector").value = savedLang; // Set dropdown value
    changeLanguage(savedLang);
}

// ✅ Event Listener for Language Selection
document.addEventListener("DOMContentLoaded", () => {
    loadLanguage();
    document.getElementById("language-selector").addEventListener("change", function () {
        changeLanguage(this.value);
    });
});
